function openModal() {
    document.getElementById("modalOverlay").style.display = "flex";
}

function closeModal() {
    document.getElementById("modalOverlay").style.display = "none";
}

function openModal1() {
    document.getElementById("modalOverlay1").style.display = "flex";
}

function closeModal1() {
    document.getElementById("modalOverlay1").style.display = "none";
}
function openModal2() {
    document.getElementById("modalOverlay2").style.display = "flex";
}

function closeModal2() {
    document.getElementById("modalOverlay2").style.display = "none";
}
function openModal3() {
    document.getElementById("modalOverlay3").style.display = "flex";
}

function closeModal3() {
    document.getElementById("modalOverlay3").style.display = "none";
}

function openModal4() {
    document.getElementById("modalOverlay4").style.display = "flex";
}

function closeModal4() {
    document.getElementById("modalOverlay4").style.display = "none";
}